import com.github.kwhat.jnativehook.GlobalScreen;
import com.github.kwhat.jnativehook.NativeHookException;
import com.github.kwhat.jnativehook.keyboard.NativeKeyEvent;
import com.github.kwhat.jnativehook.keyboard.NativeKeyListener;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import java.awt.*;
import java.awt.event.*;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Main extends JFrame implements NativeKeyListener {
    private static final Color INK = new Color(12, 13, 18);
    private static final Color PANEL = new Color(24, 25, 33);
    private static final Color PANEL_2 = new Color(34, 35, 45);
    private static final Color RED = new Color(232, 35, 49);
    private static final Color CREAM = new Color(248, 244, 230);
    private static final Color GOLD = new Color(255, 199, 67);
    private static final Color MUTED = new Color(165, 166, 177);

    private static final DateTimeFormatter CLOCK =
            DateTimeFormatter.ofPattern("HH:mm:ss.SSSSSSSSS");

    private final List<Movement> recording =
            Collections.synchronizedList(new ArrayList<>());
    private final Set<Integer> heldKeys = Collections.synchronizedSet(new HashSet<>());
    private final AtomicBoolean isRecording = new AtomicBoolean(false);
    private final AtomicBoolean isPlaying = new AtomicBoolean(false);

    private final DefaultListModel<String> logModel = new DefaultListModel<>();
    private final JLabel statusValue = new JLabel("STANDBY");
    private final JLabel countValue = new JLabel("00");
    private final JLabel timerValue = new JLabel("00:00.000");
    private final JLabel lastActionValue = new JLabel("Awaiting hero input...");
    private final JButton recordButton = actionButton("●  START RECORDING", RED);
    private final JButton playButton = actionButton("▶  PLAY MACRO", GOLD);
    private final JButton undoButton = actionButton("↶  UNDO", PANEL_2);
    private final JButton clearButton = actionButton("✕  CLEAR", PANEL_2);
    private final JList<String> activityList = new JList<>(logModel);

    private long recordingStartNanos;
    private long lastEventNanos;
    private LocalDateTime lastDisplayTime;
    private volatile boolean closing;

    private static class Movement {
        final int keyCode;
        final String key;
        final String action;
        final long elapsedNanos;
        final LocalDateTime displayTime;

        Movement(int keyCode, String key, String action,
                 long elapsedNanos, LocalDateTime displayTime) {
            this.keyCode = keyCode;
            this.key = key;
            this.action = action;
            this.elapsedNanos = elapsedNanos;
            this.displayTime = displayTime;
        }
    }

    public Main() {
        super("U.A. HERO OPERATIONS // MOVEMENT MACRO");
        setDefaultCloseOperation(WindowConstants.DO_NOTHING_ON_CLOSE);
        setMinimumSize(new Dimension(1100, 700));
        setSize(1320, 820);
        setLocationRelativeTo(null);
        setContentPane(buildInterface());

        recordButton.addActionListener(e -> toggleRecording());
        playButton.addActionListener(e -> playMacro(true));
        undoButton.addActionListener(e -> undoLast());
        clearButton.addActionListener(e -> clearRecording());

        addWindowListener(new WindowAdapter() {
            @Override public void windowClosing(WindowEvent e) {
                shutdown();
            }
        });

        installGlobalKeyboardHook();
        refreshControls();
    }

    private JPanel buildInterface() {
        JPanel root = new JPanel(new BorderLayout(18, 18)) {
            @Override protected void paintComponent(Graphics g) {
                super.paintComponent(g);
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setColor(INK);
                g2.fillRect(0, 0, getWidth(), getHeight());
                g2.setColor(new Color(255, 255, 255, 13));
                for (int x = -getHeight(); x < getWidth(); x += 24) {
                    g2.drawLine(x, 0, x + getHeight(), getHeight());
                }
                g2.setColor(new Color(RED.getRed(), RED.getGreen(), RED.getBlue(), 35));
                g2.fillPolygon(new int[]{getWidth()-260, getWidth(), getWidth(), getWidth()-390},
                        new int[]{0, 0, 210, 125}, 4);
                g2.dispose();
            }
        };
        root.setBorder(new EmptyBorder(22, 24, 22, 24));
        root.setOpaque(false);

        root.add(buildHeader(), BorderLayout.NORTH);

        JPanel center = new JPanel(new BorderLayout(18, 0));
        center.setOpaque(false);
        center.add(buildControlArea(), BorderLayout.CENTER);
        center.add(buildActivityPanel(), BorderLayout.EAST);
        root.add(center, BorderLayout.CENTER);
        root.add(buildFooter(), BorderLayout.SOUTH);
        return root;
    }

    private JComponent buildHeader() {
        JPanel header = new JPanel(new BorderLayout());
        header.setOpaque(false);

        JPanel brand = new JPanel();
        brand.setOpaque(false);
        brand.setLayout(new BoxLayout(brand, BoxLayout.Y_AXIS));

        JLabel eyebrow = new JLabel("U.A. HIGH  //  HERO COURSE SUPPORT SYSTEM");
        eyebrow.setForeground(GOLD);
        eyebrow.setFont(new Font("Arial", Font.BOLD, 12));

        JLabel title = new JLabel("HERO  ACTION");
        title.setForeground(CREAM);
        title.setFont(new Font("Arial Black", Font.BOLD, 42));

        JLabel subtitle = new JLabel("MOVEMENT MACRO  •  TRAINING DIVISION 01");
        subtitle.setForeground(MUTED);
        subtitle.setFont(new Font("Arial", Font.BOLD, 12));

        brand.add(eyebrow);
        brand.add(Box.createVerticalStrut(3));
        brand.add(title);
        brand.add(subtitle);

        JPanel status = new JPanel();
        status.setOpaque(false);
        status.setLayout(new BoxLayout(status, BoxLayout.Y_AXIS));
        status.setAlignmentX(Component.RIGHT_ALIGNMENT);

        JLabel system = new JLabel("● SYSTEM STATUS");
        system.setForeground(RED);
        system.setFont(new Font("Arial", Font.BOLD, 12));
        statusValue.setForeground(CREAM);
        statusValue.setFont(new Font("Arial Black", Font.BOLD, 20));
        statusValue.setAlignmentX(Component.RIGHT_ALIGNMENT);
        system.setAlignmentX(Component.RIGHT_ALIGNMENT);
        status.add(system);
        status.add(Box.createVerticalStrut(5));
        status.add(statusValue);

        header.add(brand, BorderLayout.WEST);
        header.add(status, BorderLayout.EAST);
        return header;
    }

    private JComponent buildControlArea() {
        JPanel area = new JPanel(new BorderLayout(0, 16));
        area.setOpaque(false);

        JPanel heroBanner = new JPanel(new BorderLayout(12, 0));
        heroBanner.setBackground(RED);
        heroBanner.setBorder(new EmptyBorder(14, 18, 14, 18));
        JLabel bannerTitle = new JLabel("PLUS ULTRA!");
        bannerTitle.setForeground(Color.WHITE);
        bannerTitle.setFont(new Font("Arial Black", Font.BOLD, 28));
        JLabel bannerSub = new JLabel("CAPTURE YOUR MOVEMENT. REPLAY YOUR TECHNIQUE.");
        bannerSub.setForeground(Color.WHITE);
        bannerSub.setFont(new Font("Arial", Font.BOLD, 11));
        heroBanner.add(bannerTitle, BorderLayout.WEST);
        heroBanner.add(bannerSub, BorderLayout.SOUTH);

        JPanel content = new JPanel(new BorderLayout(0, 16));
        content.setOpaque(false);
        content.add(buildStats(), BorderLayout.NORTH);
        content.add(buildControlsCard(), BorderLayout.CENTER);

        area.add(heroBanner, BorderLayout.NORTH);
        area.add(content, BorderLayout.CENTER);
        return area;
    }

    private JComponent buildStats() {
        JPanel stats = new JPanel(new GridLayout(1, 3, 12, 0));
        stats.setOpaque(false);
        stats.add(statCard("RECORDED ACTIONS", countValue));
        stats.add(statCard("SESSION TIMER", timerValue));
        stats.add(statCard("LAST ACTION", lastActionValue));
        return stats;
    }

    private JPanel statCard(String heading, JLabel value) {
        JPanel card = new JPanel(new BorderLayout(0, 8));
        card.setBackground(PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255,255,255,35), 1),
                new EmptyBorder(13, 15, 13, 15)));
        JLabel label = new JLabel(heading);
        label.setForeground(MUTED);
        label.setFont(new Font("Arial", Font.BOLD, 10));
        value.setForeground(CREAM);
        value.setFont(new Font("Arial Black", Font.BOLD, 19));
        value.setToolTipText(heading);
        card.add(label, BorderLayout.NORTH);
        card.add(value, BorderLayout.CENTER);
        return card;
    }

    private JComponent buildControlsCard() {
        JPanel card = new JPanel(new BorderLayout(0, 16));
        card.setBackground(PANEL);
        card.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255,255,255,45), 1),
                new EmptyBorder(18, 18, 18, 18)));

        JLabel heading = new JLabel("QUIRK CONTROL // SUPPORTED KEYS");
        heading.setForeground(CREAM);
        heading.setFont(new Font("Arial Black", Font.BOLD, 18));

        JPanel keys = new JPanel(new GridLayout(2, 4, 10, 10));
        keys.setOpaque(false);
        String[][] controls = {
                {"W", "MOVE UP"}, {"A", "MOVE LEFT"}, {"S", "MOVE DOWN"}, {"D", "MOVE RIGHT"},
                {"J", "JUMP"}, {"R", "RUN"}, {"Q", "DODGE"}, {"F", "BLOCK"}
        };
        for (String[] control : controls) keys.add(keyTile(control[0], control[1]));

        JPanel actions = new JPanel(new GridLayout(2, 2, 10, 10));
        actions.setOpaque(false);
        actions.add(recordButton);
        actions.add(playButton);
        actions.add(undoButton);
        actions.add(clearButton);

        JLabel note = new JLabel("<html>GLOBAL CAPTURE: Start recording, switch to your game, then use W A S D J R Q F. "
                + "Only these eight controls are collected. F9 toggles recording; F10 plays immediately while the game is focused. The PLAY button gives you a 3-second window to switch to the game.</html>");
        note.setForeground(MUTED);
        note.setFont(new Font("Arial", Font.PLAIN, 12));

        JPanel lower = new JPanel(new BorderLayout(0, 12));
        lower.setOpaque(false);
        lower.add(actions, BorderLayout.CENTER);
        lower.add(note, BorderLayout.SOUTH);

        card.add(heading, BorderLayout.NORTH);
        card.add(keys, BorderLayout.CENTER);
        card.add(lower, BorderLayout.SOUTH);
        return card;
    }

    private JComponent keyTile(String key, String label) {
        JPanel tile = new JPanel(new BorderLayout(0, 4));
        tile.setBackground(PANEL_2);
        tile.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(RED.getRed(), RED.getGreen(), RED.getBlue(), 150), 1),
                new EmptyBorder(10, 8, 10, 8)));
        JLabel keyLabel = new JLabel(key, SwingConstants.CENTER);
        keyLabel.setForeground(GOLD);
        keyLabel.setFont(new Font("Arial Black", Font.BOLD, 28));
        JLabel actionLabel = new JLabel(label, SwingConstants.CENTER);
        actionLabel.setForeground(CREAM);
        actionLabel.setFont(new Font("Arial", Font.BOLD, 10));
        tile.add(keyLabel, BorderLayout.CENTER);
        tile.add(actionLabel, BorderLayout.SOUTH);
        return tile;
    }

    private JComponent buildActivityPanel() {
        JPanel panel = new JPanel(new BorderLayout(0, 12));
        panel.setPreferredSize(new Dimension(345, 100));
        panel.setBackground(new Color(18, 19, 26));
        panel.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(RED, 2),
                new EmptyBorder(15, 14, 15, 14)));

        JPanel top = new JPanel(new BorderLayout());
        top.setOpaque(false);
        JLabel title = new JLabel("ACTION LOG");
        title.setForeground(CREAM);
        title.setFont(new Font("Arial Black", Font.BOLD, 20));
        JLabel live = new JLabel("● LIVE FEED");
        live.setForeground(RED);
        live.setFont(new Font("Arial", Font.BOLD, 10));
        top.add(title, BorderLayout.WEST);
        top.add(live, BorderLayout.EAST);

        JLabel explanation = new JLabel("<html>KEY  /  ACTION  /  LOCAL TIME<br>Nanosecond precision • oldest to newest</html>");
        explanation.setForeground(MUTED);
        explanation.setFont(new Font("Arial", Font.PLAIN, 10));

        activityList.setBackground(new Color(18, 19, 26));
        activityList.setForeground(CREAM);
        activityList.setFont(new Font("Consolas", Font.PLAIN, 11));
        activityList.setSelectionBackground(new Color(RED.getRed(), RED.getGreen(), RED.getBlue(), 90));
        activityList.setSelectionForeground(Color.WHITE);
        activityList.setFixedCellHeight(48);

        JScrollPane scroll = new JScrollPane(activityList);
        scroll.setBorder(BorderFactory.createLineBorder(new Color(255,255,255,30)));
        scroll.getViewport().setBackground(new Color(18, 19, 26));

        panel.add(top, BorderLayout.NORTH);
        panel.add(scroll, BorderLayout.CENTER);
        panel.add(explanation, BorderLayout.SOUTH);
        return panel;
    }

    private JComponent buildFooter() {
        JPanel footer = new JPanel(new BorderLayout());
        footer.setOpaque(false);
        JLabel left = new JLabel("HERO SUPPORT DIVISION  //  INPUT PLAYBACK MODULE");
        left.setForeground(MUTED);
        left.setFont(new Font("Arial", Font.BOLD, 10));
        JLabel right = new JLabel("F9  RECORD TOGGLE     F10  INSTANT PLAY");
        right.setForeground(GOLD);
        right.setFont(new Font("Arial", Font.BOLD, 10));
        footer.add(left, BorderLayout.WEST);
        footer.add(right, BorderLayout.EAST);
        return footer;
    }

    private static JButton actionButton(String text, Color background) {
        JButton button = new JButton(text);
        button.setFocusPainted(false);
        button.setForeground(Color.WHITE);
        button.setBackground(background);
        button.setFont(new Font("Arial Black", Font.BOLD, 13));
        button.setBorder(BorderFactory.createCompoundBorder(
                BorderFactory.createLineBorder(new Color(255,255,255,65), 1),
                new EmptyBorder(13, 12, 13, 12)));
        button.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        button.setOpaque(true);
        return button;
    }

    private void installGlobalKeyboardHook() {
        Logger.getLogger(GlobalScreen.class.getPackage().getName()).setLevel(Level.OFF);
        try {
            GlobalScreen.registerNativeHook();
            GlobalScreen.addNativeKeyListener(this);
        } catch (NativeHookException ex) {
            JOptionPane.showMessageDialog(this,
                    "Could not start global keyboard capture.\n"
                            + "Try closing other keyboard-hook tools and restarting.\n\n" + ex.getMessage(),
                    "Keyboard Hook Error", JOptionPane.ERROR_MESSAGE);
            statusValue.setText("HOOK ERROR");
        }
    }

    private void toggleRecording() {
        if (isPlaying.get()) return;
        if (isRecording.get()) {
            isRecording.set(false);
            statusValue.setText("STANDBY");
            recordButton.setText("●  START RECORDING");
            recordButton.setBackground(RED);
        } else {
            isRecording.set(true);
            recordingStartNanos = System.nanoTime();
            statusValue.setText("RECORDING");
            recordButton.setText("■  STOP RECORDING");
            recordButton.setBackground(new Color(135, 25, 35));
        }
        refreshControls();
    }

    private String actionFor(int code) {
        switch (code) {
            case NativeKeyEvent.VC_W: return "MOVE UP";
            case NativeKeyEvent.VC_A: return "MOVE LEFT";
            case NativeKeyEvent.VC_S: return "MOVE DOWN";
            case NativeKeyEvent.VC_D: return "MOVE RIGHT";
            case NativeKeyEvent.VC_J: return "JUMP";
            case NativeKeyEvent.VC_R: return "RUN";
            case NativeKeyEvent.VC_Q: return "DODGE";
            case NativeKeyEvent.VC_F: return "BLOCK";
            default: return null;
        }
    }

    private String keyFor(int code) {
        switch (code) {
            case NativeKeyEvent.VC_W: return "W";
            case NativeKeyEvent.VC_A: return "A";
            case NativeKeyEvent.VC_S: return "S";
            case NativeKeyEvent.VC_D: return "D";
            case NativeKeyEvent.VC_J: return "J";
            case NativeKeyEvent.VC_R: return "R";
            case NativeKeyEvent.VC_Q: return "Q";
            case NativeKeyEvent.VC_F: return "F";
            default: return null;
        }
    }

    @Override public void nativeKeyPressed(NativeKeyEvent event) {
        int code = event.getKeyCode();

        if (code == NativeKeyEvent.VC_F9) {
            SwingUtilities.invokeLater(this::toggleRecording);
            return;
        }
        if (code == NativeKeyEvent.VC_F10) {
            SwingUtilities.invokeLater(() -> playMacro(false));
            return;
        }

        String action = actionFor(code);
        String key = keyFor(code);
        if (action == null || key == null || !isRecording.get()) return;
        if (!heldKeys.add(code)) return;

        long now = System.nanoTime();
        long elapsed = now - recordingStartNanos;
        LocalDateTime displayTime = LocalDateTime.now();

        synchronized (recording) {
            if (lastDisplayTime != null && !displayTime.isAfter(lastDisplayTime)) {
                displayTime = lastDisplayTime.plusNanos(1);
            }
            lastDisplayTime = displayTime;
            lastEventNanos = now;
            Movement movement = new Movement(code, key, action, elapsed, displayTime);
            recording.add(movement);
            SwingUtilities.invokeLater(() -> addMovementToLog(movement));
        }
    }

    @Override public void nativeKeyReleased(NativeKeyEvent event) {
        heldKeys.remove(event.getKeyCode());
    }

    @Override public void nativeKeyTyped(NativeKeyEvent event) { }

    private void addMovementToLog(Movement movement) {
        String time = CLOCK.format(movement.displayTime);
        logModel.addElement(String.format("%-2s  %-11s  %s", movement.key, movement.action, time));
        activityList.ensureIndexIsVisible(logModel.size() - 1);
        countValue.setText(String.format("%02d", recording.size()));
        lastActionValue.setText(movement.key + " / " + movement.action);
        updateTimer();
        refreshControls();
    }

    private void updateTimer() {
        if (!isRecording.get() || recordingStartNanos == 0) return;
        long millis = (System.nanoTime() - recordingStartNanos) / 1_000_000;
        long minutes = millis / 60_000;
        long seconds = (millis / 1_000) % 60;
        long remainder = millis % 1_000;
        timerValue.setText(String.format("%02d:%02d.%03d", minutes, seconds, remainder));
    }

    private void playMacro(boolean giveFocusTime) {
        if (isRecording.get()) {
            isRecording.set(false);
            recordButton.setText("●  START RECORDING");
            recordButton.setBackground(RED);
        }
        if (!isPlaying.compareAndSet(false, true)) return;

        List<Movement> snapshot;
        synchronized (recording) {
            snapshot = new ArrayList<>(recording);
        }
        if (snapshot.isEmpty()) {
            isPlaying.set(false);
            JOptionPane.showMessageDialog(this, "Record some movements before playback.",
                    "No Training Data", JOptionPane.INFORMATION_MESSAGE);
            refreshControls();
            return;
        }

        statusValue.setText(giveFocusTime ? "SWITCH TO GAME" : "PLAYING");
        refreshControls();

        Thread playbackThread = new Thread(() -> {
            try {
                if (giveFocusTime) {
                    for (int seconds = 3; seconds > 0 && !closing; seconds--) {
                        final int remaining = seconds;
                        SwingUtilities.invokeLater(() ->
                                statusValue.setText("SWITCH IN " + remaining));
                        Thread.sleep(1000);
                    }
                }
                Robot robot = new Robot();
                long previous = snapshot.get(0).elapsedNanos;
                for (int i = 0; i < snapshot.size() && !closing; i++) {
                    Movement movement = snapshot.get(i);
                    if (i > 0) {
                        long waitNanos = Math.max(0, movement.elapsedNanos - previous);
                        sleepNanos(waitNanos);
                    }
                    if (closing) break;
                    robot.keyPress(toAwtKeyCode(movement.key));
                    robot.delay(45);
                    robot.keyRelease(toAwtKeyCode(movement.key));
                    previous = movement.elapsedNanos;
                    final int step = i + 1;
                    SwingUtilities.invokeLater(() -> {
                        lastActionValue.setText("PLAY " + step + " / " + snapshot.size());
                    });
                }
            } catch (Exception ex) {
                SwingUtilities.invokeLater(() -> JOptionPane.showMessageDialog(this,
                        "Playback failed: " + ex.getMessage(), "Playback Error",
                        JOptionPane.ERROR_MESSAGE));
            } finally {
                isPlaying.set(false);
                SwingUtilities.invokeLater(() -> {
                    statusValue.setText(isRecording.get() ? "RECORDING" : "STANDBY");
                    refreshControls();
                });
            }
        }, "HeroMacroPlayback");
        playbackThread.setDaemon(true);
        playbackThread.start();
    }

    private static int toAwtKeyCode(String key) {
        return KeyEvent.getExtendedKeyCodeForChar(key.charAt(0));
    }

    private static void sleepNanos(long nanos) throws InterruptedException {
        long millis = nanos / 1_000_000;
        int extraNanos = (int) (nanos % 1_000_000);
        Thread.sleep(millis, extraNanos);
    }

    private void undoLast() {
        synchronized (recording) {
            if (recording.isEmpty()) return;
            recording.remove(recording.size() - 1);
            rebuildLog();
        }
    }

    private void clearRecording() {
        if (isRecording.get() || isPlaying.get()) {
            JOptionPane.showMessageDialog(this, "Stop recording or playback before clearing.",
                    "Training In Progress", JOptionPane.WARNING_MESSAGE);
            return;
        }
        synchronized (recording) {
            recording.clear();
            lastDisplayTime = null;
            lastEventNanos = 0;
        }
        logModel.clear();
        countValue.setText("00");
        timerValue.setText("00:00.000");
        lastActionValue.setText("Awaiting hero input...");
        refreshControls();
    }

    private void rebuildLog() {
        logModel.clear();
        for (Movement movement : recording) {
            logModel.addElement(String.format("%-2s  %-11s  %s",
                    movement.key, movement.action, CLOCK.format(movement.displayTime)));
        }
        countValue.setText(String.format("%02d", recording.size()));
        if (recording.isEmpty()) lastActionValue.setText("Awaiting hero input...");
        else {
            Movement last = recording.get(recording.size() - 1);
            lastActionValue.setText(last.key + " / " + last.action);
        }
        refreshControls();
    }

    private void refreshControls() {
        playButton.setEnabled(!isPlaying.get() && !recording.isEmpty());
        undoButton.setEnabled(!isPlaying.get() && !recording.isEmpty());
        clearButton.setEnabled(!isPlaying.get() && !isRecording.get());
    }

    private void shutdown() {
        closing = true;
        isRecording.set(false);
        try {
            if (GlobalScreen.isNativeHookRegistered()) GlobalScreen.unregisterNativeHook();
        } catch (NativeHookException ignored) { }
        dispose();
        System.exit(0);
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Main app = new Main();
            app.setVisible(true);
            new Timer(100, e -> app.updateTimer()).start();
        });
    }
}
