# Hero Academy Macro

A Java Swing desktop macro recorder with a dramatic red/black manga-inspired interface.

## Requirements
- JDK 21
- Visual Studio Code
- Extension Pack for Java
- Maven (VS Code's Maven for Java extension can also import the Maven project)
- Windows/macOS/Linux desktop session that permits global keyboard hooks

## Open in VS Code
1. Extract the ZIP.
2. In VS Code choose File > Open Folder and select `HeroAcademyMacro`.
3. Allow the Java/Maven project to import and download dependencies.
4. Open `src/main/java/Main.java`.
5. Run `mvn clean compile exec:java` in the integrated terminal.

## Controls
- Click START RECORDING, then switch to the target application/game.
- Only W, A, S, D, J, R, Q and F are recorded.
- Click STOP RECORDING when finished.
- PLAY MACRO starts a 3-second countdown so you can switch to the game before keys are sent.
- F9 toggles recording; F10 starts playback immediately (press it while the game is focused).
- UNDO removes the latest recorded event; CLEAR removes the recording.

## Timestamp behavior
The activity log uses local date/time with nanosecond display precision. If two captured events receive the same or out-of-order wall-clock value, the displayed timestamp is advanced by one nanosecond to guarantee strictly increasing timestamps. Playback timing is measured separately with `System.nanoTime()`.

## Important
This tool globally observes only the eight configured movement keys while recording is active. It does not collect passwords or general text input. Use it only in applications/games where macros and automated input are permitted. Some games block synthetic input or prohibit macros; do not use it to bypass anti-cheat or game rules. Keep the macro window open while recording/playback.
